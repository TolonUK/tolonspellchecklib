Enchant Unit Tests are written using the UnitTest++ framework.

See http://unittest-cpp.sourceforge.net/ for more details.
